#
# Copyright 2016 AppFormix Inc.
#

# AppFormix Controller constants
REST_TIMEOUT = 60
ASYNC_TASK_WAIT_MILLISECONDS = 200
ASYNC_TASK_ITERATIONS = 10
APPFORMIX_BASE = '/appformix/controller/v2.0'
APPFORMIX_ANALYTICS_BASE = '/appformix/analytics/v2.0'
TASK_STATE_URL = APPFORMIX_BASE + '/task/{0}/state'
TASK_RESULT_URL = APPFORMIX_BASE + '/task/{0}/result'
AUTH_CREDENTIALS_URL = APPFORMIX_BASE + '/auth_credentials'
ALARM_URL = APPFORMIX_BASE + '/alarms'
COMPOSITE_ALARM_URL = APPFORMIX_ANALYTICS_BASE + '/composite_alarms/spec'
NOTIFICATION_ACCOUNT_URL = APPFORMIX_BASE + '/notifications'
ALARM_NOTIFIER_URL = APPFORMIX_BASE + '/alarms/notifications'
COMPOSITE_ALARM_NOTIFIER_URL = APPFORMIX_BASE + '/composite_alarms/notifications'
AGGREGATE_URL = APPFORMIX_BASE + '/aggregates'
ALARM_DESCRIBE_URL = APPFORMIX_BASE + '/describe/alarms'

COMPOSITE_ALARM_TYPE = 'composite_alarm'
AGGREGATION_FUNCTION_CHOICES = ['average', 'max', 'min', 'std-dev', 'sum']
COMPARISON_FUNCTION_CHOICES = ['below', 'equal', 'above',
                               'increasing-at-a-minimum-rate-of',
                               'decreasing-at-a-minimum-rate-of']

ALARM_SCOPE_INSTANCE = 'instance'
COMPOSITE_ALARM_SCOPE_AGGREGATE = 'aggregate'
COMPOSITE_ALARM_SCOPE_PROJECT = 'project'
ALARM_SCOPE_ALL_INSTANCES = 'all_instances'
ALARM_STATE_ENABLED = 'enabled'
ALARM_STATE_DISABLED = 'disabled'
ALARM_MODE_EVENT = 'event'
ALARM_MODE_ALERT = 'alert'
NOTIFICATION_TYPE_HEAT = 'OpenstackHeatNotifier'
AGGREGATE_TYPE_MIXED = 'mixed'
AGGR_HEAT_METADATA = 'type=heat'
ENTITY_SOURCE_OPENSTACK = 'openstack'

MILLISECONDS_IN_ONE_SECOND = 1000
