#
# Copyright 2016 AppFormix Inc.
#

from oslo_log import log as logging
from heat.common import exception
from heat.common.i18n import _
from heat.engine import constraints
from heat.engine import properties
from heat.engine import resource

import appformix_constants
from appformix_alarm_util import (create_appformix_controller,
                                  get_resource_ids,
                                  add_id_to_resource_ids,
                                  check_aggr_exists,
                                  create_alarm_notifier_data,
                                  create_notification_account_data,
                                  create_aggr_data,
                                  create_alarm_data,
                                  create_composite_alarm_data,
                                  ALARM_SCHEMA)
import json
import copy

LOG = logging.getLogger(__name__)


class AppFormixCompositeAlarm(resource.Resource):

    PROPERTIES = (
        COMPOSITE_ALARM_NAME, AGGREGATE_ID, PROJECT_ID,
        COMPOSITE_ALARM_THRESHOLD, NOTIFICATION_URL, COMPOSITE_ALARM_RULES
    ) = (
        'composite_alarm_name', 'aggregate_id', 'project_id',
        'composite_alarm_threshold', 'notification_url',
        'composite_alarm_rules'
    )
    COMPOSITE_ALARM_RULES_MAPPING_KEYS = (
        ALARM_WEIGHT,
    ) = (
        'alarm_weight',
    )
    composite_alarm_schema = copy.deepcopy(ALARM_SCHEMA)
    composite_alarm_schema.update({
        ALARM_WEIGHT: properties.Schema(
                properties.Schema.NUMBER,
                _('The weight to be assigned to this alarm when evaluating '
                  'the composite alarm. Must be a value between 0 and 1'),
                required=True,
                constraints=[constraints.Range(0, 1)]
            )
    })

    properties_schema = {
        COMPOSITE_ALARM_NAME: properties.Schema(
            properties.Schema.STRING,
            _('Name that identifies the composite alarm'),
            required=True
        ),
        AGGREGATE_ID: properties.Schema(
            properties.Schema.STRING,
            _('ID of aggregate containing instances on which alarm '
              'should be evaluated'),
            required=False
        ),
        PROJECT_ID: properties.Schema(
            properties.Schema.STRING,
            _('ID of project containing instances on which alarm '
              'should be evaluated'),
            required=False
        ),
        COMPOSITE_ALARM_THRESHOLD: properties.Schema(
            properties.Schema.NUMBER,
            _('The value by which to determine if the composite alarm is '
              'active. This value is compared to the sum of the weights of '
              'all active alarms. Must be a value between 0 and 1'),
            required=True,
            constraints=[constraints.Range(0, 1)]
        ),
        NOTIFICATION_URL: properties.Schema(
            properties.Schema.STRING,
            _('URL to send notification to when the composite '
              'alarm is active'),
            required=True
        ),
        COMPOSITE_ALARM_RULES: properties.Schema(
            properties.Schema.LIST,
            _('List of alarms that are part of this Composite Alarm'),
            required=True,
            schema=properties.Schema(
                properties.Schema.MAP,
                schema=composite_alarm_schema
            )
        ),
    }

    def handle_create(self):
        self.appformix_controller = create_appformix_controller(
            self.stack.context.auth_token)
        # Get the project_id and aggregate_id
        proj_id = self.properties['project_id']
        aggr_id = self.properties['aggregate_id']
        # Create aggregate in AppFormix, if it doesn't already exist.
        if aggr_id:
            stack_name = self.stack.name
            project_id = self.stack.context.tenant_id
            aggr_data = create_aggr_data(stack_name, aggr_id, project_id)
            aggr_exists = check_aggr_exists(self.appformix_controller,
                                            aggr_id,
                                            aggr_data)
            if not aggr_exists:
                aggr = self.appformix_controller.add_aggregate(aggr_data)
                LOG.info(u'Successfully created aggregate with id={0} '
                         'data={1}'.format(aggr_id, aggr_data))
            self.resource_id_set(add_id_to_resource_ids(self.resource_id,
                                                        'aggr_id',
                                                        aggr_id))

        # Create alarms defined in composite alarm.
        alarm_ids = []
        alarm_metrics = []
        try:
            alarm_metrics = self.appformix_controller.get_alarm_metrics()
        except Exception as e:
            msg = (u'Could not validate alarm metric: {0}'.format(e))
            raise exception.StackValidationFailed(message=msg)
        for alarm_properties in self.properties['composite_alarm_rules']:
            alarm_metric = alarm_properties['alarm_metric']
            if alarm_metric not in alarm_metrics:
                msg = (u'Invalid alarm_metric. Choices are: {0}'.
                       format(alarm_metrics))
                raise exception.StackValidationFailed(message=msg)
            alarm_data = create_alarm_data(
                alarm_properties,
                stack_id=self.stack.id,
                aggr_id=aggr_id,
                proj_id=proj_id,
                is_composite_alarm=True,
                composite_alarm_name=self.properties['composite_alarm_name'])
            alarm = self.appformix_controller.add_alarm(alarm_data)
            alarm_id = alarm['EventRule']['EventRuleId']
            alarm_ids.append(alarm_id)
            LOG.info(u'Successfully created alarm with id={0} data={1}'.
                     format(alarm_id, alarm_data))

        # Create composite alarm
        try:
            composite_alarm_data = create_composite_alarm_data(
                alarm_properties=self.properties,
                stack_id=self.stack.id,
                aggr_id=aggr_id,
                proj_id=proj_id,
                alarm_ids=alarm_ids)
            alarm = self.appformix_controller.add_composite_alarm(
                composite_alarm_data)
            composite_alarm_id = alarm['CompositeAlarm']['CompositeAlarmId']
            self.resource_id_set(add_id_to_resource_ids(self.resource_id,
                                                        'composite_alarm_id',
                                                        composite_alarm_id))
            LOG.info(u'Successfully created composite alarm with id={0} '
                     'data={1}'.format(composite_alarm_id,
                                       composite_alarm_data))
        except:
            # Delete all alarms that were created for the composite alarm
            # and re-raise the exception that was generated when the
            # composite alarm creation failed.
            for alarm_id in alarm_ids:
                try:
                    self.appformix_controller.delete_alarm(alarm_id)
                except:
                    pass
            raise

        # Create notification account
        notification_url = self.properties['notification_url']
        account_data = create_notification_account_data(notification_url)
        account = \
            self.appformix_controller.add_notification_account(account_data)
        account_id = account['ServiceKeyUser']['ServiceKey']
        self.resource_id_set(add_id_to_resource_ids(self.resource_id,
                                                    'account_id',
                                                    account_id))
        LOG.info(u'Successfully created notification account with id={0} '
                 'data={1}'.format(account_id, account_data))

        # Add notifier for composite alarm
        notifier_data = create_alarm_notifier_data(notification_id=account_id,
                                                   alarm_id=composite_alarm_id,
                                                   is_alarm=False)
        notifier = \
            self.appformix_controller.add_notifier_for_composite_alarm(
                notifier_data)
        notifier_id = notifier['ServiceKeyAnalytics']['Id']
        self.resource_id_set(add_id_to_resource_ids(self.resource_id,
                                                    'notifier_id',
                                                    notifier_id))
        LOG.info(u'Successfully created notifier with id={0} alarm={1}'.
                 format(notifier_id, alarm_id))

    def handle_delete(self):
        self.appformix_controller = create_appformix_controller(
            self.stack.context.auth_token)
        resource_id_dict = get_resource_ids(self.resource_id)
        notifier_id = resource_id_dict.get('notifier_id')
        account_id = resource_id_dict.get('account_id')
        composite_alarm_id = resource_id_dict.get('composite_alarm_id')
        # Handle all exceptions so that one failure doesn't cause the
        # delete_stack operation to fail.
        try:
            if notifier_id:
                self.appformix_controller.delete_notifier_for_composite_alarm(
                    notifier_id)
        except Exception as e:
            LOG.warning(u'Exception while deleting notifier for alarm: {0}'.
                        format(e))
        try:
            if account_id:
                self.appformix_controller.delete_notification_account(
                    account_id)
        except Exception as e:
            LOG.warning(u'Exception while deleting notification account: {0}'.
                        format(e))
        # Delete the alarms defined in the composite_alarm
        try:
            if composite_alarm_id:
                try:
                    alarm_ids = self.appformix_controller.\
                        get_alarm_ids_from_composite_alarm(composite_alarm_id)
                except Exception as e:
                    LOG.warning(u'Exception while getting alarm ids from '
                                'controller: {0}'.format(e))
                if alarm_ids:
                    for alarm_id in alarm_ids:
                        try:
                            self.appformix_controller.delete_alarm(alarm_id)
                            LOG.info(u'Successfully deleted alarms={}'.
                                     format(alarm_ids))
                        except Exception as e:
                            LOG.warning(u'Exception while deleting alarm: {0}'.
                                        format(e))
        except Exception as e:
            LOG.warning(u'Exception while deleting alarms in '
                        'composite alarm: {0}'.format(e))
        try:
            if composite_alarm_id:
                self.appformix_controller.delete_composite_alarm(
                    composite_alarm_id)
        except Exception as e:
            LOG.warning(u'Exception while deleting composite alarm: {0}'.
                        format(e))
        LOG.info(u'Successfully deleted notifier={0} account={1} '
                 'composite alarm={2}'.
                 format(notifier_id, account_id, composite_alarm_id))

    def handle_suspend(self):
        self.appformix_controller = create_appformix_controller(
            self.stack.context.auth_token)
        resource_id_dict = get_resource_ids(self.resource_id)
        # Suspend the alarms
        composite_alarm_id = resource_id_dict.get('composite_alarm_id')
        try:
            alarm_ids = self.appformix_controller.\
                get_alarm_ids_from_composite_alarm(composite_alarm_id)
            for alarm_id in alarm_ids:
                alarm_json = \
                    {'Status': appformix_constants.ALARM_STATE_DISABLED}
                self.appformix_controller.update_alarm(alarm_id,
                                                       alarm_json)
        except Exception as e:
            LOG.error(u'Exception while suspending composite alarm: {0}'.
                      format(e))

    def handle_resume(self):
        self.appformix_controller = create_appformix_controller(
            self.stack.context.auth_token)
        resource_id_dict = get_resource_ids(self.resource_id)
        composite_alarm_id = resource_id_dict.get('composite_alarm_id')
        try:
            alarm_ids = self.appformix_controller.\
                get_alarm_ids_from_composite_alarm(composite_alarm_id)
            # Resume the alarms
            for alarm_id in alarm_ids:
                alarm_json = \
                    {'Status': appformix_constants.ALARM_STATE_ENABLED}
                self.appformix_controller.update_alarm(alarm_id,
                                                       alarm_json)
        except Exception as e:
            LOG.error(u'Exception while resuming composite alarm: {0}'.
                      format(e))

    def handle_update(self, json_snippet, tmpl_diff, prop_diff):
        msg = 'Cannot update OS::AppFormix::CompositeAlarm resource type'
        raise exception.Error(msg=msg)

    def handle_check(self):
        pass


def resource_mapping():
    return {
        'OS::AppFormix::CompositeAlarm': AppFormixCompositeAlarm,
    }
