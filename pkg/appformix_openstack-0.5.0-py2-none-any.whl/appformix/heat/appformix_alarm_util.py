#
# Copyright 2018 AppFormix Inc.
#

from oslo_log import log as logging
from heat.common import exception
from heat.common.i18n import _
from heat.engine import properties
from heat.engine import constraints
try:
    from oslo.config import cfg
except:
    from oslo_config import cfg

import appformix_constants
from appformix_util import AppformixController
import json

LOG = logging.getLogger(__name__)


appformix_controller_url = cfg.StrOpt(
    'appformix_controller_url',
    help='AppFormix Controller URL')

appformix_task_num_iterations = cfg.IntOpt(
    'appformix_task_num_iterations',
    help='Number of times the plugin will check for status of an AppFormix '
         'API request before declaring that the operation has timed out',
    default=appformix_constants.ASYNC_TASK_ITERATIONS)

appformix_task_wait_milliseconds = cfg.IntOpt(
    'appformix_task_wait_milliseconds',
    help='Number of milliseconds to wait before checking the status of an '
         'AppFormix API request',
    default=appformix_constants.ASYNC_TASK_WAIT_MILLISECONDS)

CONF = cfg.CONF
CONF.register_opt(appformix_controller_url)
CONF.register_opt(appformix_task_num_iterations)
CONF.register_opt(appformix_task_wait_milliseconds)

PROPERTIES = (
    ALARM_NAME, ALARM_METRIC, AGGREGATION_FUNCTION,
    COMPARISON_FUNCTION, DURATION, NUM_INTERVALS,
    NUM_EXCEPTION_INTERVALS, THRESHOLD
) = (
    'alarm_name', 'alarm_metric', 'aggregation_function',
    'comparison_function', 'duration', 'num_intervals',
    'num_exception_intervals', 'threshold'
)

ALARM_SCHEMA = {
    ALARM_NAME: properties.Schema(
        properties.Schema.STRING,
        _('Name that identifies the alarm'),
        required=True
    ),
    ALARM_METRIC: properties.Schema(
        properties.Schema.STRING,
        _('Metric to evaluate'),
        required=True
    ),
    AGGREGATION_FUNCTION: properties.Schema(
        properties.Schema.STRING,
        _('Operation to use for combining measured values before comparison'),
        constraints=[
            constraints.AllowedValues(
                appformix_constants.AGGREGATION_FUNCTION_CHOICES),
        ],
        required=True
    ),
    COMPARISON_FUNCTION: properties.Schema(
        properties.Schema.STRING,
        _('Operation to use for comparing measured values to the threshold'),
        constraints=[
            constraints.AllowedValues(
                appformix_constants.COMPARISON_FUNCTION_CHOICES),
        ],
        required=True
    ),
    DURATION: properties.Schema(
        properties.Schema.INTEGER,
        _('Number of seconds for which sample values will be collected '
          'before being combined'),
        required=True
    ),
    NUM_INTERVALS: properties.Schema(
        properties.Schema.INTEGER,
        _('Number of intervals of length DURATION for which data will be '
          'collected before comparison'),
        required=True
    ),
    NUM_EXCEPTION_INTERVALS: properties.Schema(
        properties.Schema.INTEGER,
        _('Number of intervals of length DURATION for which the alarm '
          'condition has to be true for the alarm to be considered active'),
        required=True
    ),
    THRESHOLD: properties.Schema(
        properties.Schema.INTEGER,
        _('Value by which to compare a metric measurement'),
        required=True
    ),
}

def create_appformix_controller(auth_token):
    if not CONF.appformix_controller_url:
        msg = ('Failed to create stack. \'appformix_controller_url\' ' +
               'not defined in Heat configuration file')
        raise exception.Error(msg=msg)

    return AppformixController(
        base_url=CONF.appformix_controller_url,
        async_wait_ms=CONF.appformix_task_wait_milliseconds,
        async_iterations=CONF.appformix_task_num_iterations,
        auth_token=auth_token)

def get_resource_ids(resource_id):
    if resource_id is None:
        return {}
    return json.loads(resource_id)

def add_id_to_resource_ids(resource_id, id_name, id_value):
    if resource_id is None:
        resource_id_dict = {}
    else:
        resource_id_dict = json.loads(resource_id)
    resource_id_dict[id_name] = id_value
    return json.dumps(resource_id_dict)

def check_aggr_exists(appformix_controller, aggr_id, aggr_data):
    try:
        aggr = appformix_controller.get_aggregate(aggr_id)
        aggr = aggr['Aggregate']
        for key in ['Name', 'Type', 'Metadata', 'Source']:
            if aggr[key] != aggr_data[key]:
                msg = (u'Aggregate with id={0} data={1} already exists in '
                       'AppFormix'.format(aggr_id, aggr))
                raise exception.StackValidationFailed(message=msg)
        return True
    except exception.Error as e:
        return False

def create_aggr_data(stack_name, aggr_id, project_id):
    aggr_json = {
        'Name': stack_name,
        'Id': aggr_id,
        'Type': appformix_constants.AGGREGATE_TYPE_MIXED,
        'ObjectMap': {},
        'Metadata': appformix_constants.AGGR_HEAT_METADATA +
            ',projectid=' + project_id,
        'Source': appformix_constants.ENTITY_SOURCE_OPENSTACK
    }
    return aggr_json

def create_alarm_notifier_data(notification_id, alarm_id, is_alarm):
    notification_json = {
        'ServiceKey': notification_id
    }
    if is_alarm:
        notification_json['EventRuleId'] = alarm_id
    else:
        notification_json['CompositeRuleId'] = alarm_id
    return notification_json

def create_notification_account_data(notification_url):
    return {
        'NotificationEndpoint': notification_url,
        'NotificationSystemType': appformix_constants.NOTIFICATION_TYPE_HEAT
    }

def create_alarm_data(alarm_properties, stack_id, aggr_id, proj_id,
                      is_composite_alarm, composite_alarm_name=None):
    alarm_json = {
        'MetricType': alarm_properties['alarm_metric'],
        'AggregationFunction': alarm_properties['aggregation_function'],
        'ComparisonFunction': alarm_properties['comparison_function'],
        'Threshold': alarm_properties['threshold'],
    }
    if is_composite_alarm:
        alarm_json['Name'] = (stack_id + ':' +
                              composite_alarm_name + ':' +
                              alarm_properties['alarm_name'])
        alarm_json['DisplayEvent'] = False
        alarm_json['Mode'] = appformix_constants.ALARM_MODE_ALERT
    else:
        alarm_json['Name'] = (stack_id + ':' +
                              alarm_properties['alarm_name'])
        alarm_json['DisplayEvent'] = True
        alarm_json['Mode'] = appformix_constants.ALARM_MODE_EVENT
    _set_alarm_scope(alarm_json, aggr_id, proj_id)
    _set_alarm_duration(alarm_json, alarm_properties)
    return alarm_json

def create_composite_alarm_data(alarm_properties, stack_id,
                                aggr_id, proj_id, alarm_ids):
    alarm_json = {
        'CompositeAlarmName': (stack_id + ':' +
                               alarm_properties['composite_alarm_name']),
        'CompositeAlarmType': appformix_constants.COMPOSITE_ALARM_TYPE,
        'CompositeAlarmMode': appformix_constants.ALARM_MODE_EVENT
    }
    _set_composite_alarm_scope(alarm_json, aggr_id, proj_id)
    _make_rule_set(alarm_properties, alarm_json, alarm_ids)
    return alarm_json

def _set_composite_alarm_scope(alarm_json, aggr_id, proj_id):
    if proj_id and aggr_id:
        msg = ('Only one of project_id and aggregate_id may '
               'be specified')
        raise exception.StackValidationFailed(message=msg)
    if proj_id:
        alarm_json['ObjectId'] = proj_id
        alarm_json['CompositeAlarmScope'] = \
            appformix_constants.COMPOSITE_ALARM_SCOPE_PROJECT
    elif aggr_id:
        alarm_json['ObjectId'] = aggr_id
        alarm_json['CompositeAlarmScope'] = \
            appformix_constants.COMPOSITE_ALARM_SCOPE_AGGREGATE
    else:
        msg = ('One of project_id and aggregate_id should be specified')
        raise exception.StackValidationFailed(message=msg)

def _make_rule_set(alarm_properties, alarm_json, alarm_ids):
    alarm_json['Rulesets'] = []
    ruleset = {}
    ruleset['RuleList'] = alarm_ids
    ruleset['RulesetObjectId'] = alarm_json['ObjectId']
    ruleset['Threshold'] = alarm_properties['composite_alarm_threshold']
    ruleset['WeightList'] = \
        [alarm['alarm_weight'] for alarm in alarm_properties[
            'composite_alarm_rules']]
    alarm_json['Rulesets'].append(ruleset)

def _set_alarm_duration(alarm_json, alarm_properties):
    alarm_json['IntervalDuration'] = \
        str(alarm_properties['duration']) + 's'
    alarm_json['IntervalCount'] = alarm_properties['num_intervals']
    alarm_json['IntervalsWithException'] = \
        alarm_properties['num_exception_intervals']

def _set_alarm_scope(alarm_json, aggr_id, proj_id):
    alarm_json['EventRuleScope'] = appformix_constants.ALARM_SCOPE_INSTANCE
    if proj_id and aggr_id:
        msg = ('Only one of project_id and aggregate_id may '
              'be specified')
        raise exception.StackValidationFailed(message=msg)
    if proj_id:
        alarm_json['ProjectId'] = proj_id
    elif aggr_id:
        alarm_json['AggregateId'] = aggr_id
    else:
        msg = ('One of project_id and aggregate_id should be specified')
        raise exception.StackValidationFailed(message=msg)
