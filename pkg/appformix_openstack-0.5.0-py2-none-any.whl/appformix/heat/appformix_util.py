#
# Copyright 2016 AppFormix Inc.
#

from heat.common import exception

import appformix_constants
import json
import requests
import time


session = requests.Session()
session_functions = {'POST': session.post,
                     'GET': session.get,
                     'PUT': session.put,
                     'DELETE': session.delete
                     }


class AppformixController(object):

    def __init__(self, base_url, async_wait_ms, async_iterations, auth_token):
        self.base_url = base_url
        self.async_wait = \
            (float(async_wait_ms) /
             appformix_constants.MILLISECONDS_IN_ONE_SECOND)
        self.async_iterations = async_iterations
        self.auth_token = auth_token

    # Makes a REST call to AppFormix controller
    def _make_rest_call(self,
                        rest_type,
                        endpoint,
                        data=None,
                        timeout=appformix_constants.REST_TIMEOUT):
        url = self.base_url + endpoint
        headers = {'Content-type': 'application/json',
                   'X-Auth-Type': 'openstack'}
        headers['X-Auth-Token'] = self.auth_token
        function = session_functions.get(rest_type)
        resp = function(url=url,
                        data=data,
                        headers=headers,
                        timeout=timeout)
        return resp

    def _get_result(self, resp):
        self._check_response(resp)
        return json.loads(resp.text)

    def _get_result_async(
            self,
            resp,
            allow_400_already_exists=False):
        self._check_response(resp, allow_400_already_exists)
        if allow_400_already_exists and resp.status_code == 400:
            return
        task_id = json.loads(resp.text).get('task_id')
        if not task_id:
            msg = (u'In AppformixController::_get_result_async: '
                    'task id not received')
            raise exception.Error(msg=msg)
        return self._wait_for_async_task(task_id)

    # Waits for an asynchronous REST call to complete on
    # AppFormix controller.
    def _wait_for_async_task(self, task_id):
        task_state_endpoint = appformix_constants.\
            TASK_STATE_URL.format(task_id)
        task_result_endpoint = appformix_constants.\
            TASK_RESULT_URL.format(task_id)
        for iteration in xrange(self.async_iterations):
            resp = self._make_rest_call(rest_type='GET',
                                        endpoint=task_state_endpoint)
            task_state = self._get_result(resp)
            if ('PENDING' == task_state):
                # Task is still running. Wait and check again
                time.sleep(self.async_wait)
            else:
                try:
                    resp = self._make_rest_call(
                        rest_type='GET',
                        endpoint=task_result_endpoint)
                    task_result = self._get_result(resp)
                except RequestError:
                    # Retry
                    continue
                if ('SUCCESS' == task_state):
                    return task_result
                else:
                    msg = (u'In AppformixController::_wait_for_async_task: '
                           'task_id={0} response={1}'.
                           format(task_id, task_result))
                    raise exception.Error(msg=msg)
        # Task has not completed in the expected time.
        msg = (u'In AppformixController::_wait_for_async_task: task={0} timed '
               'out after {1} iterations of {2} seconds'.
               format(task_id, self.async_iterations, self.async_wait))
        raise exception.Error(msg=msg)

    def _check_response(self, resp, allow_400_already_exists=False):
        if resp is None:
            msg = (u'In AppformixController::_check_response: '
                   'received empty response')
            raise exception.Error(msg=msg)

        status_code = resp.status_code
        error = resp.text

        if not str(status_code).startswith('2'):
            if (allow_400_already_exists and status_code == 400 and
                    'already exists' in str(error)):
                return
            msg = (u'In AppformixController::_check_response: received '
                   'status_code={0} response={1}'.
                   format(resp.status_code, resp.text))
            raise exception.Error(msg=msg)

    def add_alarm(self, data):
        endpoint = appformix_constants.ALARM_URL
        res = self._make_rest_call(rest_type='POST',
                                   endpoint=endpoint,
                                   data=json.dumps(data))
        result = self._get_result_async(res)
        return result

    def delete_alarm(self, alarm_id):
        endpoint = appformix_constants.ALARM_URL + '/' + alarm_id
        res = self._make_rest_call(rest_type='DELETE',
                                   endpoint=endpoint,
                                   data=None)
        result = self._get_result_async(res)
        return result

    def update_alarm(self, alarm_id, data):
        endpoint = appformix_constants.ALARM_URL + '/' + alarm_id
        res = self._make_rest_call(rest_type='PUT',
                                   endpoint=endpoint,
                                   data=json.dumps(data))
        result = self._get_result_async(res)
        return result

    def add_composite_alarm(self, data):
        endpoint = appformix_constants.COMPOSITE_ALARM_URL
        res = self._make_rest_call(rest_type='POST',
                                   endpoint=endpoint,
                                   data=json.dumps(data))
        result = self._get_result(res)
        return result

    def delete_composite_alarm(self, alarm_id):
        endpoint = appformix_constants.COMPOSITE_ALARM_URL + '/' + alarm_id
        res = self._make_rest_call(rest_type='DELETE',
                                   endpoint=endpoint,
                                   data=None)
        result = self._get_result(res)
        return result

    def add_notification_account(self, data):
        endpoint = appformix_constants.NOTIFICATION_ACCOUNT_URL
        res = self._make_rest_call(rest_type='POST',
                                   endpoint=endpoint,
                                   data=json.dumps(data))
        result = self._get_result(res)
        return result

    def delete_notification_account(self, account_id):
        endpoint = (appformix_constants.NOTIFICATION_ACCOUNT_URL + '/' +
                    account_id)
        res = self._make_rest_call(rest_type='DELETE',
                                   endpoint=endpoint,
                                   data=None)
        result = self._get_result(res)
        return result

    def add_notifier_for_alarm(self, data):
        endpoint = appformix_constants.ALARM_NOTIFIER_URL
        res = self._make_rest_call(rest_type='POST',
                                   endpoint=endpoint,
                                   data=json.dumps(data))
        result = self._get_result(res)
        return result

    def delete_notifier_for_alarm(self, notifier_id):
        endpoint = appformix_constants.ALARM_NOTIFIER_URL + '/' + notifier_id
        res = self._make_rest_call(rest_type='DELETE',
                                   endpoint=endpoint,
                                   data=None)
        result = self._get_result(res)
        return result

    def add_notifier_for_composite_alarm(self, data):
        endpoint = appformix_constants.COMPOSITE_ALARM_NOTIFIER_URL
        res = self._make_rest_call(rest_type='POST',
                                   endpoint=endpoint,
                                   data=json.dumps(data))
        result = self._get_result(res)
        return result

    def delete_notifier_for_composite_alarm(self, notifier_id):
        endpoint = (appformix_constants.COMPOSITE_ALARM_NOTIFIER_URL + '/' +
                    notifier_id)
        res = self._make_rest_call(rest_type='DELETE',
                                   endpoint=endpoint,
                                   data=None)
        result = self._get_result(res)
        return result

    def get_aggregate(self, id):
        endpoint = appformix_constants.AGGREGATE_URL + '/' + id
        res = self._make_rest_call(rest_type='GET',
                                   endpoint=endpoint,
                                   data=None)
        result = self._get_result(res)
        return result

    def add_aggregate(self, data):
        endpoint = appformix_constants.AGGREGATE_URL
        res = self._make_rest_call(rest_type='POST',
                                   endpoint=endpoint,
                                   data=json.dumps(data))
        result = self._get_result_async(res, allow_400_already_exists=True)
        return result

    def get_alarm_ids_from_composite_alarm(self, composite_alarm_id):
        endpoint = (appformix_constants.COMPOSITE_ALARM_URL + '/' +
                    composite_alarm_id)
        res = self._make_rest_call(rest_type='GET',
                                   endpoint=endpoint,
                                   data=None)
        result = self._get_result(res)
        alarm_ids = result['CompositeAlarm']['Rulesets'][0]['RuleList']
        return alarm_ids

    def get_alarm_metrics(self):
        endpoint = appformix_constants.ALARM_DESCRIBE_URL
        res = self._make_rest_call(rest_type='GET',
                                   endpoint=endpoint,
                                   data=None)
        result = self._get_result(res)
        return [metric.get('Value') for metric in result['EventRuleParams']
                ['MetricTypeMap'][0]['static']['instance']]
