#
# Copyright 2015 AppFormix Inc.
#

# AppFormix Filter for Nova

from nova.scheduler import filters
import requests
import json
from nova.i18n import _LW

try:
    from oslo.config import cfg
    from nova.openstack.common import log as logging
except:
    from oslo_config import cfg
    from oslo_log import log as logging


session = requests.Session()
HEADERS = {'Content-type': 'application/json',
           'X-Auth-Type': 'appformix'}
TIMEOUT = 10

LOG = logging.getLogger(__name__)

appformix_controller_url = cfg.StrOpt('appformix_controller_url',
                                      help='AppFormix Controller URL')
appformix_verify_cert = cfg.BoolOpt('appformix_verify_cert',
                                    help='If false, plugin will not verify certificate for HTTPS connection.',
                                    default=True)
appformix_api_token = cfg.StrOpt('appformix_api_token',
                                 help='AppFormix API Token')

CONF = cfg.CONF
CONF.register_opt(appformix_controller_url)
CONF.register_opt(appformix_verify_cert)
CONF.register_opt(appformix_api_token)
SCHEDULING_URL = '/appformix/analytics/v2.0/composite_alarms/state?type=scheduling&scope=host&entity_id='


class AppFormixFilter(filters.BaseHostFilter):
    def __init__(self):
        LOG.info(_LW(
            "AppFormixFilter initialized"))

    def _create_scheduling_url(self, host):
        if not CONF.appformix_controller_url:
            return None
        appformix_controller_url = CONF.appformix_controller_url
        url = appformix_controller_url + SCHEDULING_URL + host
        return url

    def _get_scheduling_status(self, host):
        url = self._create_scheduling_url(host)
        if url is None:
            LOG.warning(_LW(
                "appformix_controller_url is missing in nova.conf."))
            return
        if not CONF.appformix_api_token:
            LOG.warning(_LW(
                "appformix_api_token is missing in nova.conf."))
            return
        HEADERS['X-Auth-Token'] = CONF.appformix_api_token
        try:
            resp = session.get(url=url, headers=HEADERS,
                               timeout=TIMEOUT,
                               verify=CONF.appformix_verify_cert)
            if str(resp.status_code)[0] in ['4', '5']:
                LOG.warning(_LW(
                    "State request failed for host '%s': url='%s' resp='%s'"),
                    host, url, resp.text)
                return

            return json.loads(resp.text)
        except Exception as e:
            LOG.warning(_LW(
                "State request failed for host '%s': url='%s' exception='%s'"),
                host, url, e)

    def host_passes(self, host_state, filter_properties):
        """Return True if host is ok to schedule"""

        host_id = host_state.host
        if not host_id:
            # Fail safe
            LOG.warning(_LW(
                "No host_id for '%s'"),
                host_state)
            return True

        host_id = host_id.replace('.', '_')
        host_scheduling_status = self._get_scheduling_status(host_id)

        if host_scheduling_status and 'State' in host_scheduling_status:
            if host_scheduling_status['State'][0]['description'] == "scheduling not ok":
                LOG.info(_LW(
                    "Host '%s' does not meet scheduling SLA because '%s'"),
                    host_state, host_scheduling_status['State'][0]['reason'])
                return False

        return True
