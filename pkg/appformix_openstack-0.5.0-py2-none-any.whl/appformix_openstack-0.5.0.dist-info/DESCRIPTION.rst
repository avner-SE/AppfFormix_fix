ABOUT
=====
AppFormix provides plugins to OpenStack Nova and Heat services.

The AppFormixFilter for Nova is a plugin that filters which hosts are
eligible candidates on which to schedule a virtual machine.  The
AppFormixFilter queries the AppFormix platform to determine if a host is
compliant with the Host Scheduling SLA. If a host is not compliant with
the SLA policy, then the host will be filtered from the list of eligible
hosts.  If the AppFormixFilter fails to request SLA status of a host,
then the host will remain in the eligible pool.

For Heat, AppFormix provides a Resource type called
'OS::AppFormix::Alarm'.  This resource type can be used in Heat
templates to create an AppFormix Alarm.  The alarm can be used for
auto-scaling.


INSTALLATION
============

Install the AppFormix Python package for OpenStack on the OpenStack
controller hosts that execute OpenStack services (e.g., Nova and Heat).

    pip install appformix_openstack-0.3.0-py2-none-any.whl


Nova Scheduler Filter Plugin
----------------------------

To use AppFormixFilter in OpenStack Nova scheduler, you must modify the
configuration in /etc/nova/nova.conf.  The following instructions apply to
OpenStack Juno release and later.

In /etc/nova/nova.conf, add the following lines under the `[DEFAULT]`
section:

    #
    # Configure AppFormix Controller URL used by AppFormixFilter.
    # Setting `scheduler_available_filters` enables AppFormixFilter as
    # an available as a choice to configure in `scheduler_default_filters`.
    # The appformix-openstack Python package must be installed on the host
    # that executes nova-scheduler service.
    #
    # If `appformix_controller_url` has HTTPS as its protocol, and the host
    # has a self-signed certificate, then set `appformix_verify_cert` to
    # false to ignore verification of the certificate.  By default,
    # `appformix_verify_cert` is True.
    #
    # Set 'appformix_api_token' to the value of 'TokenId' from
    # the file /opt/appformix/etc/appformix_token.rst on the AppFormix Platform host.
    #
    appformix_controller_url = <base URL, e.g., http://appformix_platform_host:9000/>
    #appformix_verify_cert = True
    scheduler_available_filters = appformix.openstack.nova_filters.AppFormixFilter
    appformix_api_token = <AppFormix token from /opt/appformix/etc/appformix_token.rst>


    #
    # The following are sample configuration values for nova-scheduler to
    # use the FilterScheduler.  The key addition is to include
    # AppFormixFilter in the list of `scheduler_available_filters`.
    #
    scheduler_driver_task_period = 60
    scheduler_driver = nova.scheduler.filter_scheduler.FilterScheduler
    scheduler_available_filters = nova.scheduler.filters.all_filters
    scheduler_default_filters = AppFormixFilter, DiskFilter, RetryFilter, CoreFilter, AvailabilityZoneFilter, RamFilter, ComputeFilter, ComputeCapabilitiesFilter, ImagePropertiesFilter, ServerGroupAntiAffinityFilter, ServerGroupAffinityFilter


Finally, restart OpenStack nova scheduler service:

    service nova-scheduler restart

For debugging, enable verbose in nova.conf by adding `verbose=True` under
`[DEFAULT]` section in /etc/nova/nova.conf.


Heat Resources
--------------

After installing the appformix-openstack Python package, the AppFormix
Heat resources will be available in:

    /usr/local/lib/python2.7/dist-packages/appformix/heat

Modify the Heat configuration file to add this directory to the list of
plugin directories.  In /etc/heat/heat.conf, look for the 'plugin_dirs'
entry in the '[DEFAULT]' section, and modify it as follows:

    [DEFAULT]
    ...
    plugin_dirs = [...],/usr/local/lib/python2.7/dist-packages/appformix/heat
    ...

Finally, restart all the OpenStack Heat services.

    service heat-api restart
    service heat-api-cfn restart
    service heat-engine restart


For debugging, enable the `verbose` setting in heat.conf by adding or
uncommenting the `verbose = true` line in the `[DEFAULT]` section in
/etc/heat/heat.conf.


